.. cmake-module:: ../../Modules/CPackArchive.cmake
