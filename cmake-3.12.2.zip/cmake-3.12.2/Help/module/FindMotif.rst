.. cmake-module:: ../../Modules/FindMotif.cmake
