<!--
// objective: test markdown parsing
// check: md_055_markdown.xml
-->

# Foo

## Bar

[Inline link](http://example.com/inline)

[Reference link][1]

[1]: http://example.com/reference

## Baz

More text

[Upper-cased reference link on last line][U]

[U]: http://example.com/last-line

Dash - NDash -- MDash --- EDash \- ENDash \-- EMDash \--- E3Dash \-\-\-
