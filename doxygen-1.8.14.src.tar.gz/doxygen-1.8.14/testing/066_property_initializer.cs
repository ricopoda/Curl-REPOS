// objective: C# property initializer
// check: class_class1.xml
class Class1
{
  public int Property1 { get; } = 1;
  public string Property2 { get; set; }
}
